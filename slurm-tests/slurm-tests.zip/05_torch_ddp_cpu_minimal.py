import os, socket, time
import torch
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data import Dataset, DataLoader, DistributedSampler

class ToyDataset(Dataset):
    def __init__(self, n=200000, d=32):
        g = torch.Generator().manual_seed(123)
        self.x = torch.randn(n, d, generator=g)
        # y = x @ w + noise
        w = torch.linspace(-1, 1, d)
        self.y = (self.x * w).sum(dim=1, keepdim=True) + 0.01 * torch.randn(n, 1, generator=g)

    def __len__(self): return self.x.size(0)
    def __getitem__(self, i): return self.x[i], self.y[i]

def main():
    rank = int(os.environ["RANK"])
    world = int(os.environ["WORLD_SIZE"])
    dist.init_process_group(backend="gloo", init_method="env://")

    host = socket.gethostname().split(".")[0]
    if rank == 0:
        print(f"[rank0] world={world} master={os.environ.get('MASTER_ADDR')}:{os.environ.get('MASTER_PORT')}", flush=True)

    torch.set_num_threads(2)  # evita oversubscription (ajustable)

    model = torch.nn.Sequential(
        torch.nn.Linear(32, 64),
        torch.nn.ReLU(),
        torch.nn.Linear(64, 1),
    )
    ddp = DDP(model)

    ds = ToyDataset(n=120000, d=32)
    sampler = DistributedSampler(ds, num_replicas=world, rank=rank, shuffle=True, drop_last=True)
    dl = DataLoader(ds, batch_size=256, sampler=sampler, num_workers=0, pin_memory=False)

    opt = torch.optim.SGD(ddp.parameters(), lr=0.05)
    loss_fn = torch.nn.MSELoss()

    t0 = time.time()
    for epoch in range(3):
        sampler.set_epoch(epoch)
        running = 0.0
        nb = 0
        for x, y in dl:
            opt.zero_grad(set_to_none=True)
            pred = ddp(x)
            loss = loss_fn(pred, y)
            loss.backward()
            opt.step()
            running += loss.item()
            nb += 1

        # Promedio global de loss (para verificar sincronía)
        loss_tensor = torch.tensor(running / nb)
        dist.all_reduce(loss_tensor, op=dist.ReduceOp.SUM)
        loss_avg = (loss_tensor / world).item()

        if rank == 0:
            print(f"[epoch {epoch}] loss_avg={loss_avg:.6f} elapsed={time.time()-t0:.2f}s", flush=True)

    dist.destroy_process_group()
    if rank == 0:
        print("[rank0] DONE", flush=True)

if __name__ == "__main__":
    main()
